﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidBody;
    public Text txt_Score;
    public float Score = 5;
    public int nextlevel;
    

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidBody = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidBody.AddForce(movement * speed * Time.deltaTime);
        if(Score == 0)
        {
            SceneManager.LoadScene(nextlevel);
        }

    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Coin")
        {
            Destroy(collision.gameObject);
            Score--;
            txt_Score.text = "Coin Collected = " + Score;            
       }
       if(collision.collider.tag == "Hazards")
        {            
            SceneManager.LoadScene(1);
        }
       
    }
}
